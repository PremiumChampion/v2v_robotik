namespace HHN_Client
{
    void createConnection() {} // create tcp client
} // namespace Client
