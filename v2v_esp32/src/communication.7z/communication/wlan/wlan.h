namespace WLAN
{
    void setup();
    // String pass = lsdkjhfslk;
    // String name = lsdkfhslfjd;
    // entweder AccessPoint oder Connection
    // new AccessPoint(pass, name);
    // new Connection(pass, name);
} // namespace WLAN
