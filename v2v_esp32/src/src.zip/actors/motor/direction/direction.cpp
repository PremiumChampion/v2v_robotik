#include "direction.h"
#include "actors/actors.h"
#include <Arduino.h>

namespace Actors
{
    HHN_V_MotorDirection::HHN_V_MotorDirection(Actor actor) : HHN_V_Actor(actor)
    {
    }
} // namespace Actors
