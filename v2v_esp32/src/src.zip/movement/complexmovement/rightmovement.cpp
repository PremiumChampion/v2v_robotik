#include <Arduino.h>
#include "rightmovement.h"
#include "sensors/sensors.h"
#include "vehicle/vehicle.h"

namespace Movement
{
    RightMovement::RightMovement() : BasicMovement() {}
    void RightMovement::run() {}
} // namespace Movement
