#include <Arduino.h>
#include "leftmovement.h"
#include "sensors/sensors.h"
#include "vehicle/vehicle.h"

namespace Movement
{
    LeftMovement::LeftMovement() : BasicMovement() {}
    void LeftMovement::run() {}

} // namespace Movement
