#include "basicmovement.h"

namespace Movement
{
    bool BasicMovement::isComplete()
    {
        return this->isDone;
    }
} // namespace Movement
